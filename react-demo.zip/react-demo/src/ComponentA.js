import React, { createContext, useEffect, useState } from 'react'

import ComponentB from './ComponentB';

export const UserContext = createContext();


// useContext() = React Hook that allows you to share values between multiple levels of components 
// without passing props through each level

// Context provides a way to pass data or state through the component tree without 
// having to pass props down manually through each nested component

export default function ComponentA() {

    const [userName, setUserName] = useState('Stephen');

    useEffect(() => {
        setUserName('Stephen Prakash');
    }, [])

    return (
        <div className='box'>
            <h2>ComponentA</h2>
            <UserContext.Provider value={userName}>
                <ComponentB />
            </UserContext.Provider>
        </div>
    )
}
