import { ACTION_TYPES } from "../Action/UserActionType"

export const INITIAL_STAGE = {
    loading: false,
    error: false,
    post: {}
}

export const userReducer = (state, action) => {
    switch (action.type) {
        case ACTION_TYPES.POST_FETCH_START:
            return {
                ...state,
                loading: true,
                error: false
            }
        case ACTION_TYPES.POST_FETCH_SUCCESS:
            return {
                ...state,
                loading: false,
                post: action.payload,
            }

        case ACTION_TYPES.POST_FETCH_FAILED:
            return {
                ...state,
                loading: false,
                error: action.error
            }
        default:
            return state;
    }
}