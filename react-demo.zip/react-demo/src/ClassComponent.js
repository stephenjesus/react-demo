import React, { Component, Fragment } from 'react'

export default class Parent extends React.Component {

    render() {

        return (
            <div>
                <ClassComponent name="Stephen"></ClassComponent>
            </div>
        )
    }
}

class ClassComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            name: "James"
        }
    }
    // The getDerivedStateFromProps() method is called right before rendering the element(s) in the DOM.
    // static getDerivedStateFromProps(props, state) {
    //     console.log(`getDerivedStateFromProps`);
    //     if (props.name !== state.name)
    //         return { name: props.name };
    //     return null; // No change to state 
    // }

    // The componentDidMount() method is called after the component is rendered.
    // This is where you run statements that requires that the component is already placed in the DOM.

    componentDidMount() {
        console.log('componentDidMount')
        setTimeout(() => {
            this.setState({ name: "Component Did Mount" })
        }, 1000)
    }

    render() {
        console.log(`RENDER`);
        return (
            <Fragment>
                <div>Class Component</div>
                <div> My Name is {this.state.name} </div>
            </Fragment>
        )
    }
}
