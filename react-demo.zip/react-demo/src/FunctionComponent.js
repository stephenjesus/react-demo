import React, { Fragment, useState, useEffect, useRef , useId } from 'react';

import './custom.css';

export default function FunctionComponent() {

    const [counter, setCount] = useState(0);

    // In React, useState is a special function that lets you add state to functional components. 
    // It provides a way to declare and manage state variables directly within a function component.
    //useState() returns an array with initial state value and a function to update it.

    // The useEffect Hook allows us to perform side effects on the components. 
    // fetching data, directly updating the DOM and timers are some side effects. 
    // It is called every time any state if the dependency array is modified or updated.

    // useEffect(<FUNCTION>, <DEPENDENCY>)
    // React useEffect Hook ShortHand for:
    // FUNCTION: contains the code to be executed when useEffect triggers.
    // DEPENDENCY: is an optional parameter, useEffect triggers when the given dependency is changed.

    // useEffect triggers a function on every component render, leveraging React to execute specified tasks efficiently.

    // 1.To run useEffect on every render do not pass any dependency
    useEffect(() => {
        console.log('every rendering');
    })
    // 2.To run useEffect only once on the first render pass any empty array in the dependency
    useEffect(() => {
        console.log('only once on the first render');
    }, [])
    //  3.To run useEffect on change of a particular value. Pass the state and props in the dependency array
    useEffect(() => {
        console.log('on change of a particular value');
        document.title = `You clicked ${counter} times`;
    }, [counter])

    // The useRef is a hook that allows to directly create a reference to the DOM element in the functional component
    const focusPoint = useRef(null);

    const userId = useId() // React useId Hook is introduced for the ReactJS versions above 18. This hook generates unique IDs 
    // i.e, returns a string that is stable across both the server and the client sides.

    const onClickHandler = () => {
        focusPoint.current.value = `You clicked ${counter} times and user id ${userId}`;
        focusPoint.current.focus();
    }

    // useContext() = React Hook that allows you to share values between multiple levels of components 
    // without passing props through each level

    // The useReducer Hook is the better alternative to the useState hook and it allows you to manage the state values
    // it generally used when the next state value depends upon its previous value OR
    // when the components are needed to be optimized.

    return (
        <Fragment>
            <div>Counter {counter}</div>
            <div>
                <button className='button' onClick={() => setCount((counter) => counter + 1)}>
                    Click me
                </button>
            </div>
            <div>
                <button className='button' onClick={onClickHandler}>
                    Action
                </button>
            </div>
            <textarea ref={focusPoint} cols={50} rows={5} />           {/* useRef */}
        </Fragment>
    )
}


// useCallback
// useMemo