
import { useReducer } from "react";
import { userReducer, INITIAL_STAGE } from "./Reducer/userReducer";
import { ACTION_TYPES } from "./Action/UserActionType";

const Post = () => {
    // USING USE STATE

    // const [loading, setLoading] = useState(false);
    // const [error, setError] = useState(false);
    // const [post, setPost] = useState({});

    // const handleFetch = () => {
    //     setLoading(true);
    //     setError(false);
    //     fetch("https://jsonplaceholder.typicode.com/posts/1")
    //         .then((res) => res.json())
    //         .then((data) => {
    //             setLoading(false);
    //             setPost(data);
    //         })
    //         .catch((err) => {
    //             setLoading(false);
    //             setError(true);
    //         });
    // };
    // //USING USE STATE
    // return <div>
    //     <button onClick={handleFetch}>
    //         {loading ? "Wait..." : "Fetch the post"}
    //     </button>
    //     <p>{post?.title}</p>
    //     <span>{error && "Something went wrong!"}</span>
    // </div>


    const [state, dispatch] = useReducer(userReducer, INITIAL_STAGE);

    const handleFetch = () => {
        dispatch({ type: ACTION_TYPES.POST_FETCH_START });
        fetch(`https://jsonplaceholder.typicode.com/posts/1`).then((res) => {
            return res.json();
          }).then((data) => {
            console.log(data , 'data');
            dispatch({ type: ACTION_TYPES.POST_FETCH_SUCCESS, payload: data })
        }).catch((err) => {
            console.log('err', err)
            dispatch({ type: ACTION_TYPES.POST_FETCH_FAILED })
        })
    }

    console.log(state ,'state');

    return <div>
        <button onClick={handleFetch}>
            {state.loading ? "Wait..." : "Fetch the post"}
        </button>
        <p>{state.post?.title}</p>
        <span>{state.error && "Something went wrong!"}</span>
    </div>
}

export default Post