import React, { useContext } from 'react'

import { UserContext } from "./ComponentA"

export default function ComponentC() {

    const user = useContext(UserContext);
    return (
        <div className='box'>
            <h2>ComponentC</h2>
            <h3> Hello {user} </h3>
        </div>
    )
}
