// import logo from './logo.svg';
import './App.css';
import FunctionComponent from './FunctionComponent';
import ComponentA from './ComponentA';
import Post from "./Post"
import Parent from './ClassComponent';
function App() {
  return (
    <div className="App">
      <h2>React Learning</h2>
      <FunctionComponent />
      <ComponentA />        {/* useContext */}
      <br></br>
      <Post />
      <Parent/>
    </div>
  );
}

export default App;
